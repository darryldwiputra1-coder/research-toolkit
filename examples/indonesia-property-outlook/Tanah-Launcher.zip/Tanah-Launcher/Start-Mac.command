#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
    echo 'Python 3.10 or newer is required: https://www.python.org/downloads/'
    read -r -p 'Press Enter to close.'
    exit 1
fi
python3 launch.py
result=$?
if [ "$result" -ne 0 ]; then
    read -r -p 'Press Enter to close.'
fi
exit "$result"
