#!/usr/bin/env python3
"""Install locally and launch Tanah; Python 3.10+ is the only prerequisite."""
import hashlib
import os
from pathlib import Path
import socket
import subprocess
import sys
import venv


def main():
    if sys.version_info < (3, 10):
        raise RuntimeError('Install Python 3.10 or newer from https://www.python.org/downloads/')
    root = Path(__file__).resolve().parent
    os.chdir(root)
    environment = root / '.venv'
    python = environment / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    if not python.exists():
        print('First launch: creating the local Python environment...', flush=True)
        venv.EnvBuilder(with_pip=True).create(environment)
    requirements = root / 'requirements.txt'
    digest = hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker = environment / '.tanah-requirements'
    installed = marker.read_text().strip() if marker.exists() else ''
    healthy = subprocess.run([str(python), '-c', 'import streamlit, pandas'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    if installed != digest or not healthy:
        print('Installing app dependencies. The first launch needs internet and may take a few minutes.', flush=True)
        subprocess.run([str(python), '-m', 'pip', 'install', '-r', str(requirements)], check=True)
        marker.write_text(digest)
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        port = probe.getsockname()[1]
    print(f'Opening Tanah at http://localhost:{port}', flush=True)
    print('Keep this window open. Press Ctrl+C to stop the app.', flush=True)
    return subprocess.call([str(python), '-m', 'streamlit', 'run', str(root / 'app.py'),
                            '--server.address=127.0.0.1', f'--server.port={port}',
                            '--server.headless=false', '--browser.serverAddress=localhost',
                            '--browser.gatherUsageStats=false'])


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print('\nTanah stopped.')
    except Exception as exc:
        print(f'\nCould not launch Tanah: {exc}', file=sys.stderr)
        print('Check Python is installed, internet is available, and the ZIP is fully extracted into a writable folder.', file=sys.stderr)
        sys.exit(1)
