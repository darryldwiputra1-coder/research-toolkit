@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel% equ 0 (
    py -3 launch.py
    goto done
)
where python >nul 2>&1
if %errorlevel% equ 0 (
    python launch.py
    goto done
)
echo Python 3.10 or newer is required.
echo Install it from https://www.python.org/downloads/
echo During installation, enable "Add Python to PATH", then run this launcher again.
:done
pause
